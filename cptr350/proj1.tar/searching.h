#include<string>
struct query
{
 myrecord *data;
 
 int x;
 int y;
 int left;
 int bottom;
 int right;
 int top;
};

class findme
{
 private:
 query *root;

 public:
};
